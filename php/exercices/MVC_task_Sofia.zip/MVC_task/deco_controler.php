<?php 
//* activation de la SESSION
session_start();

//* Suppresion de la SESSION 
session_destroy();

//* Redirection a la page d'accueil
header('Location:index.php');
exit;


