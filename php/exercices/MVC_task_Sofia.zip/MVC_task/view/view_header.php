<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/style.css">
    <title>Document</title>
</head>

<body>
    <header>
        <nav>
            <a href="index.php">Accueil/Connexion</a>
            <a href="mytasks.php" class="<?php echo $classNav ?>" >Mes Tâches</a>
            <a href="inscription_controler.php" class="<?php echo $class ?>">Inscription</a>
            <a href="mon_compte_controler.php" class="<?php echo $classNav ?>">Mon compte</a>
            <a href="deco_controler.php" class="<?php echo $classNav ?>">Deconnexion</a>
            <a href="category_controler.php" class="<?php echo $classNav ?>">Categories</a>

        </nav>
    </header>