<main>
    <h1>Mon Compte</h1>
    <p>Nom: <?php echo $name ?></p>
    <p>Prenom: <?php echo $firstName ?></p>
    <p>Login: <?php echo $login ?></p>
    <p>Password: <?php echo $psw ?></p>



</main>

</body>

</html>