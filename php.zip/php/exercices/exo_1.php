<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Exo 1</h1>
    <?php
    $varInt = 5;
    echo $varInt;

    echo "<br>";

    echo "Le type de la variable varInt est: ";
    echo gettype($varInt);

    echo "<br>";

    $varString = "Sofia";
    echo $varString;

    echo "<br>";

    $varBool = false;
    echo gettype($varBool);


    ?>
</body>
</html>