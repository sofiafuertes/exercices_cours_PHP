<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Exo 15 BDD</h1>
    <form action="" method="post">
        <input type="text" name="nom_article" placeholder="Nom de l'article">
        <input type="text" name="contenu_article" placeholder="Contenu de l'article">
        <input type="submit" name="submit" value="Ajouter">
    </form>
</body>
</html>

<?php 

$name = "";
$content = "";


function sanitize($data){
        return htmlentities(strip_tags(stripslashes(trim($data))));
}
    
function securiteArticle($a,$b){
    if(empty($a) or empty($b)){
        return "Veuillez remplir les champs vides !";
    }
    $name = sanitize($a);
    $content = sanitize($b);

    //*connexion a la bdd
    $bdd = new PDO('mysql:host=localhost;dbname=articles','root','',options: array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));


try{
    $req = $bdd ->prepare('INSERT INTO article (nom_article, contenu_article) VALUES (?,?)');

    $req -> bindParam(1,$name,PDO::PARAM_STR);
    $req -> bindParam(2,$content,PDO::PARAM_STR);
    
    $req -> execute();

}catch(EXCEPTION $error){
    echo $error -> getMessage();
}}

if(isset($_POST["submit"])){
    securiteArticle($_POST["nom_article"],$_POST["contenu_article"]);
    $name = $_POST["nom_article"];
    $content = $_POST["contenu_article"];
    echo "<p> Nom de l'article: $name</p>";
    echo "<p> Son contenu: $content</p>";
 }

?>


